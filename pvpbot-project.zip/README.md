# PvPBot (Fabric, Minecraft 1.21.4)

Команды: `/bot start [1-10]`, `/bot kill`, `/bot list`.

Сборка: вкладка Actions -> build -> Artifacts -> pvpbot-mod.
Нужны Fabric Loader 0.16.10+ и Fabric API 0.119.4+1.21.4 (на сервере и у игроков).
